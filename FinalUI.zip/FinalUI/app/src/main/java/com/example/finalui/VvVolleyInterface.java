package com.example.finalui;

/**
 * Created by Vaibhav on 9/22/2016.
 */
public interface VvVolleyInterface {
    void onTaskComplete(String result);
}
