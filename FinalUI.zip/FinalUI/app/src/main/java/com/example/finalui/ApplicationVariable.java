package com.example.finalui;

import android.accounts.Account;
import android.app.Application;

public class ApplicationVariable extends Application {
    public static class ACCOUNT_DATA{
        static String token;
    }
}
